#ifndef _time_H
#define _time_H

#include "public.h" 


extern u8 t_sec;
extern u8 t_min;
extern u8 t_hour;
extern u8 t_secflag;

void Timer0Init(void);

#endif
